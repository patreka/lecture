"""Sync SailPoint identities to Jira CMDB using parallel async requests."""

import asyncio
import json
import logging
import sys
import time
from pathlib import Path

import aiohttp
import truststore

truststore.inject_into_ssl()

sys.path.insert(0, str(Path(__file__).resolve().parent))

from dotenv import load_dotenv
import os

load_dotenv()

from config.settings import USER_ATTRIBUTES, ALLOWED_COMPANIES, COMPANY_NAME_MAP
from clients.sailpoint import SailPointClient
from transforms.filter import company_allowed
from transforms.utils import get_value, transform_value

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# Jira config
JIRA_EMAIL = os.environ["JIRA_ATLASSIAN_EMAIL"]
JIRA_API_TOKEN = os.environ["JIRA_ATLASSIAN_API_TOKEN"]
WORKSPACE_ID = os.environ["JIRA_WORKSPACE_ID"]
BASE_URL = f"https://api.atlassian.com/jsm/assets/workspace/{WORKSPACE_ID}/v1"

# Procurement - PROD / General
COMPANY_TYPE_ID = "2432"
USER_TYPE_ID = "2431"

# Attribute IDs on User object (prod)
ATTR_IDS = {
    "User": "26165",
    "Employee ID": "26762",
    "Legal Name": "26763",
    "Email - Work": "26764",
    "Business Title": "26765",
    "Supervisory Organization": "26773",
    "Cost Center": "26776",
    "Active Status": "26790",
    "Termination Date": "26791",
    "Company": "26166",
    "Manager": "26167",
    "Manager Employee ID": "26778",
    "Manager +2 Employee ID": "26781",
    "Manager +3 Employee ID": "26783",
    "Manager +4 Employee ID": "26785",
    "Manager +5 Employee ID": "26787",
    "Manager +6 Employee ID": "32801",
    "Jira": "33795",
}

# The "User" attribute is used as the label (like "Name" in sandbox)
LABEL_ATTR = "User"

# Reference fields that need Jira object IDs, not raw text
REF_USER_FIELDS = {
    "Manager",
}

# Employee ID attribute ID for reliable lookup
EMPLOYEE_ID_ATTR_ID = "26762"

CONCURRENCY = 8
CHUNK_SIZE = 100
CHECKPOINT_FILE = Path(__file__).resolve().parent / "output" / "sync_checkpoint.json"
MAPPING_FILE = Path(__file__).resolve().parent / "output" / "employee_to_jira.json"


def build_auth():
    return aiohttp.BasicAuth(JIRA_EMAIL, JIRA_API_TOKEN)


def build_ssl_context():
    """Create an SSL context that bypasses cert verification for aiohttp."""
    import ssl
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


async def api_call(session, method, url, retries=3, **kwargs):
    for attempt in range(retries):
        try:
            async with session.request(method, url, **kwargs) as resp:
                body = await resp.read()
                body_text = body.decode("utf-8", errors="replace")
                if resp.status == 429:
                    wait = int(resp.headers.get("Retry-After", 5))
                    log.warning("Rate limited, waiting %ss", wait)
                    await asyncio.sleep(wait)
                    continue
                return resp.status, body_text
        except Exception as e:
            if attempt < retries - 1:
                await asyncio.sleep(2 ** attempt)
            else:
                return 0, str(e)
    return 0, "max retries"


async def load_existing_users(session):
    """Load all existing User objects -> {employee_id: jira_object_id}.

    Finds Employee ID by attribute ID, not by position index.
    """
    log.info("Loading existing users from Jira...")
    existing = {}
    start_at = 0
    while True:
        status, body = await api_call(
            session, "POST", f"{BASE_URL}/object/aql",
            json={"qlQuery": f"objectTypeId = {USER_TYPE_ID}"},
            params={"maxResults": 25, "startAt": start_at, "includeAttributes": 1},
        )
        if status != 200:
            break
        data = json.loads(body)
        vals = data.get("values", [])
        if not vals:
            break
        for obj in vals:
            for attr in obj.get("attributes", []):
                attr_id = str(attr.get("objectTypeAttribute", {}).get("id", ""))
                if attr_id == EMPLOYEE_ID_ATTR_ID:
                    eid_vals = attr.get("objectAttributeValues", [])
                    if eid_vals:
                        eid = eid_vals[0].get("displayValue", "")
                        if eid:
                            existing[eid] = str(obj["id"])
                    break
        if data.get("isLast", True):
            break
        start_at += 25
        if start_at % 200 == 0:
            log.info("  Loaded %s users...", len(existing))

    log.info("Loaded %s existing users", len(existing))
    return existing


async def get_company_map(session):
    """Get company name -> Jira object ID mapping."""
    company_map = {}
    start_at = 0
    while True:
        status, body = await api_call(
            session, "POST", f"{BASE_URL}/object/aql",
            json={"qlQuery": f"objectTypeId = {COMPANY_TYPE_ID}"},
            params={"maxResults": 25, "startAt": start_at},
        )
        if status != 200:
            break
        data = json.loads(body)
        vals = data.get("values", [])
        if not vals:
            break
        for obj in vals:
            company_map[obj.get("label", "")] = str(obj["id"])
        if data.get("isLast", True):
            break
        start_at += 25
    log.info("Companies: %s", list(company_map.keys()))
    return company_map


def build_user_payload(ident, company_map):
    """Build the attribute payload for one user (text + company ref)."""
    attrs = []
    employee_id = str(get_value(ident, "name"))
    display_name = get_value(ident, "displayName")

    # User/Name label
    attrs.append({"objectTypeAttributeId": ATTR_IDS[LABEL_ATTR], "objectAttributeValues": [{"value": str(display_name)}]})

    for jira_name, source_path, attr_type in USER_ATTRIBUTES:
        if jira_name in REF_USER_FIELDS or jira_name == "Company":
            continue
        aid = ATTR_IDS.get(jira_name)
        if not aid:
            continue
        value = get_value(ident, source_path)
        value = transform_value(jira_name, value)
        if not value:
            continue
        attrs.append({"objectTypeAttributeId": aid, "objectAttributeValues": [{"value": str(value)}]})

    # Company reference (map SailPoint name -> CMDB name)
    sp_company = get_value(ident, "attributes.companyName")
    cmdb_company = COMPANY_NAME_MAP.get(sp_company, sp_company)
    company_obj_id = company_map.get(cmdb_company)
    if company_obj_id:
        attrs.append({"objectTypeAttributeId": ATTR_IDS["Company"], "objectAttributeValues": [{"value": company_obj_id}]})

    return employee_id, {"objectTypeId": USER_TYPE_ID, "attributes": attrs}


async def upsert_user(session, sem, employee_id, payload, existing_jira_id=None):
    """Create or update a user."""
    async with sem:
        if existing_jira_id:
            status, body = await api_call(
                session, "PUT", f"{BASE_URL}/object/{existing_jira_id}",
                json={"attributes": payload["attributes"]},
            )
            if status == 200:
                return employee_id, existing_jira_id, "updated"
            if upsert_user._error_count < 5:
                log.error("Update failed for %s: %s %s", employee_id, status, body[:200])
                upsert_user._error_count += 1
            return employee_id, None, "error"
        else:
            status, body = await api_call(
                session, "POST", f"{BASE_URL}/object/create",
                json=payload,
            )
            if status == 201:
                return employee_id, str(json.loads(body)["id"]), "created"
            if upsert_user._error_count < 5:
                log.error("Create failed for %s: %s %s", employee_id, status, body[:200])
                upsert_user._error_count += 1
            return employee_id, None, "error"

upsert_user._error_count = 0


async def upsert_users_chunked(session, filtered, company_map, existing_map):
    """Create or update all users in chunks with checkpoint saves."""
    sem = asyncio.Semaphore(CONCURRENCY)
    user_map = dict(existing_map)
    created = 0
    updated = 0
    errors = 0
    start = time.time()

    for chunk_start in range(0, len(filtered), CHUNK_SIZE):
        chunk = filtered[chunk_start:chunk_start + CHUNK_SIZE]
        chunk_num = chunk_start // CHUNK_SIZE + 1
        total_chunks = (len(filtered) + CHUNK_SIZE - 1) // CHUNK_SIZE

        tasks = []
        for ident in chunk:
            eid, payload = build_user_payload(ident, company_map)
            existing_id = existing_map.get(eid)
            tasks.append(upsert_user(session, sem, eid, payload, existing_id))

        results = await asyncio.gather(*tasks)

        chunk_created = 0
        chunk_updated = 0
        for eid, jira_id, action in results:
            if action == "created":
                user_map[eid] = jira_id
                chunk_created += 1
                created += 1
            elif action == "updated":
                chunk_updated += 1
                updated += 1
            else:
                errors += 1

        elapsed = time.time() - start
        log.info(
            "Chunk %s/%s: %s new, %s updated (%s errors) | Total: %s | %ss",
            chunk_num, total_chunks, chunk_created, chunk_updated, errors,
            len(user_map), int(elapsed),
        )

        with open(CHECKPOINT_FILE, "w") as f:
            json.dump(user_map, f)

    log.info("Upsert done: %s created, %s updated, %s errors", created, updated, errors)
    return user_map


async def link_manager(session, sem, user_jira_id, ref_updates):
    """Link manager references for one user."""
    async with sem:
        status, _ = await api_call(
            session, "PUT", f"{BASE_URL}/object/{user_jira_id}",
            json={"attributes": ref_updates},
        )
        return status == 200


async def link_managers_chunked(session, filtered, user_map):
    """Link manager references in chunks."""
    sem = asyncio.Semaphore(CONCURRENCY)
    linked = 0
    skipped = 0
    errors = 0
    start = time.time()

    for chunk_start in range(0, len(filtered), CHUNK_SIZE):
        chunk = filtered[chunk_start:chunk_start + CHUNK_SIZE]
        chunk_num = chunk_start // CHUNK_SIZE + 1
        total_chunks = (len(filtered) + CHUNK_SIZE - 1) // CHUNK_SIZE

        tasks = []
        for ident in chunk:
            employee_id = str(get_value(ident, "name"))
            user_jira_id = user_map.get(employee_id)
            if not user_jira_id:
                skipped += 1
                continue

            ref_updates = []

            # Manager reference (links to another User object)
            manager_id = str(get_value(ident, "manager.name"))
            mgr_jira = user_map.get(manager_id)
            if mgr_jira:
                ref_updates.append({"objectTypeAttributeId": ATTR_IDS["Manager"], "objectAttributeValues": [{"value": mgr_jira}]})

            if not ref_updates:
                continue

            tasks.append(link_manager(session, sem, user_jira_id, ref_updates))

        results = await asyncio.gather(*tasks)
        chunk_linked = sum(1 for r in results if r)
        chunk_errors = sum(1 for r in results if not r)
        linked += chunk_linked
        errors += chunk_errors

        elapsed = time.time() - start
        log.info(
            "Chunk %s/%s: %s linked (%s errors) | Total: %s linked | %ss elapsed",
            chunk_num, total_chunks, chunk_linked, chunk_errors, linked, int(elapsed),
        )

    return linked, skipped, errors


async def main():
    auth = build_auth()

    connector = aiohttp.TCPConnector(ssl=build_ssl_context())
    async with aiohttp.ClientSession(auth=auth, connector=connector) as session:
        # Step 1: Load existing users
        existing_map = await load_existing_users(session)

        # Step 2: Get company map
        company_map = await get_company_map(session)

        # Step 3: Fetch SailPoint identities
        log.info("Fetching SailPoint identities...")
        with SailPointClient() as sp:
            all_ids = sp.fetch_identities()
        filtered = [i for i in all_ids if company_allowed(i, ALLOWED_COMPANIES)]
        log.info("Total: %s, filtered: %s, existing in Jira: %s", len(all_ids), len(filtered), len(existing_map))

        # Step 4: Upsert users (parallel, chunked)
        log.info("=== PASS 1: Upsert %s users (concurrency=%s) ===", len(filtered), CONCURRENCY)
        start = time.time()
        user_map = await upsert_users_chunked(session, filtered, company_map, existing_map)
        log.info("Pass 1 done: %s users in %ss", len(user_map), int(time.time() - start))

        # Step 5: Link managers (parallel, chunked)
        log.info("=== PASS 2: Linking managers ===")
        start2 = time.time()
        linked, skipped, errors = await link_managers_chunked(session, filtered, user_map)
        log.info("Pass 2 done: %s linked, %s skipped, %s errors in %ss", linked, skipped, errors, int(time.time() - start2))

        # Save final mapping
        with open(MAPPING_FILE, "w") as f:
            json.dump(user_map, f)
        log.info("Saved %s mappings to %s", len(user_map), MAPPING_FILE)


if __name__ == "__main__":
    asyncio.run(main())
