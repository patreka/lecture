# SailPoint to Jira CMDB Sync

Fetches identity data from SailPoint ISC and syncs it into Jira Assets (CMDB) using the Jira Assets Object API with async parallel requests.

## Architecture

```
SailPoint ISC  --(Search API)-->  sync_cmdb.py  --(Assets Object API)-->  Jira CMDB
```

### CMDB Structure (Procurement - PROD schema)

```
General (parent object)
  ├── Company    (pre-created in UI, populated by script)
  └── User       (pre-created in UI, populated by script)
```

Object type IDs:
- General: 2430
- Company: 2432
- User: 2431

## Setup

### Prerequisites

1. Python 3.13+
2. SailPoint ISC API credentials (client_credentials grant)
3. Atlassian API token (email + token) with Assets access
4. Object types **Company** and **User** must exist in Jira Assets under the target schema

### Install

```bash
git clone https://github.com/cee-hub/Sailpoint-to-CMDB.git
cd Sailpoint-to-CMDB
python -m venv .venv
.venv/Scripts/activate   # Windows
pip install -r requirements.txt
```

### Environment Variables

Copy `.env.example` to `.env` and fill in:

```env
SAILPOINT_CLIENT_ID=<your-client-id>
SAILPOINT_CLIENT_SECRET=<your-client-secret>
SAILPOINT_BASE_URL=https://cee.api.identitynow.com

JIRA_WORKSPACE_ID=<your-workspace-id>
JIRA_ATLASSIAN_EMAIL=<your-atlassian-email>
JIRA_ATLASSIAN_API_TOKEN=<your-atlassian-api-token>
```

## Workflow

### First-Time Setup (one-time, per environment)

1. **Object types** must exist in Jira Assets UI (Company, User under General)

2. **Create reference attributes** on User in Jira UI (cannot be done via API):
   - **Company** — Object reference -> Company
   - **Manager** — Object reference -> User (self-reference)

3. **Create text attributes** on User (can be done via API):
   - Employee ID, Legal Name, Email - Work, Business Title, Supervisory Organization
   - Manager Employee ID, Cost Center, Active Status, Termination Date, Jira
   - Manager +2 through +6 Employee ID

4. **Populate companies** in Company object

5. **Run sync** — creates/updates users, links company and manager references

### Recurring Sync (daily)

```bash
python sync_cmdb.py
```

This will:
1. Load existing users from Jira (by Employee ID — upsert, no duplicates)
2. Fetch all identities from SailPoint (Search API)
3. Filter by allowed companies
4. **Pass 1**: Create new users / update existing (parallel, 8 concurrent, chunked with checkpoints)
5. **Pass 2**: Link Manager references (self-reference to other User objects)
6. Save employee-to-Jira ID mapping

Typical run: ~7 min for ~1350 users.

## Important Notes

### Upsert Logic

The script uses **Employee ID** as the unique key:
- If a user with that Employee ID exists in Jira -> **update** their attributes
- If not -> **create** new user
- Never deletes users
- Never creates duplicates

### What NOT to do with the Jira External Import API

The External Import API (`/v1/importsource/...`) has critical limitations:

1. **It creates its own object types** — it does NOT populate pre-existing manually-created objects
2. **Attribute types are cached permanently** — once set (even from a failed PUT), you cannot change them without creating a new import source
3. **A failed mapping PUT still caches** — the import source remembers attribute types from failed attempts
4. **Stuck executions cannot be cancelled via API** — returns 405, requires UI intervention
5. **Each failed attempt requires a new import source** — which means a new generated token

**Use the Assets Object API instead** (`/v1/object/create`, `/v1/object/{id}`) to populate pre-existing objects.

### Object Reference Attributes

Object reference attributes (Company, Manager) **cannot be created via API**. The API only supports creating text attributes. Reference attributes must be created manually in Jira Assets UI as a one-time setup.

When setting reference values via API, use `{"value": "<jira_object_id>"}` format (not `referencedObjectId`).

### Tokens

| Token | Purpose | Where to create |
|-------|---------|-----------------|
| SailPoint Client ID + Secret | Fetch identities | SailPoint Admin > API Clients |
| Atlassian API Token (scoped) | Create/update objects in Jira Assets | https://id.atlassian.com/manage-profile/security/api-tokens > "Create API token with scopes" |

### SailPoint Required Scopes

- `sp:search:read` — for the Search API
- `idn:identity:read` — for identity data

### Jira Atlassian API Token Required Scopes

Create a **scoped** API token under **Jira** app with these granular scopes:

**Read scopes:**
- `read:cmdb-object:jira` — read objects and their attribute values
- `read:cmdb-attribute:jira` — read object type attributes
- `read:cmdb-type:jira` — read object types
- `read:cmdb-schema:jira` — read schemas

**Write scopes:**
- `write:cmdb-object:jira` — create and update objects
- `write:cmdb-attribute:jira` — create text attributes on object types

**Optional:**
- `delete:cmdb-object:jira` — delete objects (only needed for cleanup/reset)

### Company Filter

Only these companies are synced (configured in `config/settings.py`):
- Ab Georgia LLC
- Adjarapay
- Advanced_Systems
- Cabarco
- Singular Group Georgia LLC
- Singular Trading Limited
- Singular Group Skopje LLC

SailPoint company names are mapped to CMDB names via `COMPANY_NAME_MAP` in `config/settings.py` (e.g. SailPoint "Adjarapay" -> CMDB "Adjarapay LLC").

### Attribute Mapping (Workday -> SailPoint -> CMDB)

| Workday | SailPoint Source | CMDB Name | CMDB Type | Prod Attr ID |
|---------|-----------------|-----------|-----------|-------------|
| Employee ID | `name` (top-level) | Employee ID | Text | 26762 |
| Legal Name | `displayName` (top-level) | Legal Name | Text | 26763 |
| Email - Work | `email` (top-level) | Email - Work | Text | 26764 |
| Business Title | `attributes.title` | Business Title | Text | 26765 |
| Supervisory Organization | `attributes.supervisoryOrganization` | Supervisory Organization | Text | 26773 |
| Supervisory Organization Manager | `manager.name` (employee ID) | Manager | Reference -> User | 26167 |
| Supervisory Organization Manager ID | `manager.name` | Manager Employee ID | Text | 26778 |
| Company | `attributes.companyName` | Company | Reference -> Company | 26166 |
| Cost Center | `attributes.costCenter` | Cost Center | Text | 26776 |
| Active Status | `attributes.identityState` | Active Status | Text (Yes/No) | 26790 |
| Termination Date | `attributes.endDate` | Termination Date | Text | 26791 |
| Superior Organization Manager ID +1 | `attributes.superiorOrganizationManagerId1` | Manager +2 Employee ID | Text | 26781 |
| Superior Organization Manager ID +2 | `attributes.superiorOrganizationManagerId2` | Manager +3 Employee ID | Text | 26783 |
| Superior Organization Manager ID +3 | `attributes.superiorOrganizationManagerId3` | Manager +4 Employee ID | Text | 26785 |
| Superior Organization Manager ID +4 | `attributes.superiorOrganizationManagerId4` | Manager +5 Employee ID | Text | 26787 |
| Superior Organization Manager ID +5 | `attributes.superiorOrganizationManagerId5` | Manager +6 Employee ID | Text | 32801 |
| Jira Attribute ID | `attributes.jiraAttributeId` | Jira | Text | TODO |

### Prod User Object — All 42 Attributes

The User object in prod has 42 attributes. This script populates 17 of them. The remaining 25 are managed by other systems or manually:

**Populated by this script (17):**
Employee ID, Legal Name, Email - Work, Business Title, Supervisory Organization, Manager, Manager Employee ID, Company, Cost Center, Active Status, Termination Date, Manager +2/+3/+4/+5/+6 Employee ID, Jira

**Not populated by this script (25):**
Key, Created, Updated, User, Job Title, Position, Division, COE/Brand, Business Unit, Department, Team, Number of Direct Reports, On Leave, Cost Center Hierarchy, Manager's Email, Worker's Manager, Is Manager, Manager +2/+3/+4/+5/+6 (name refs), Group, Substitute, Email, Unavailability Start/End Date CRE, Temporary Approver CRE
