# SailPoint-to-Jira Sync — Restructuring Design

## Context

The project fetches identity data from SailPoint IdentityNow, filters by
company, and imports it into Jira Service Management Assets (CMDB). It runs
as a daily automated job doing a full sync each time.

This document describes the planned restructuring from a single 631-line
script into a modular, production-ready codebase.


## Project Structure

```
sailpoint/
├── config/
│   ├── __init__.py
│   └── settings.py          # All config: URLs, companies, page size, flags
├── clients/
│   ├── __init__.py
│   ├── sailpoint.py          # SailPoint API client
│   └── jira.py               # Jira Assets client
├── transforms/
│   ├── __init__.py
│   ├── filter.py             # Company filtering
│   ├── flatten.py            # CSV flattening
│   └── reshape.py            # Jira reshaping + company extraction
├── exporters/
│   ├── __init__.py
│   ├── csv_export.py         # write_csv
│   ├── json_export.py        # write_json
│   └── mapping.py            # build_mapping / write_mapping
├── output/                   # Generated files (JSON, CSV, mapping, logs)
├── main.py                   # Orchestrator
├── .env
├── .gitignore
├── requirements.txt
└── CHANGELOG.txt
```


## config/settings.py

Centralizes all configuration. Secrets load from .env via python-dotenv.
Everything else (companies, page size, output paths) is defined here.

Jira workspace and import-source UUIDs move from hardcoded URL strings
to environment variables (JIRA_WORKSPACE_ID, JIRA_IMPORT_SOURCE_ID).

The credentials/ package is removed — settings.py replaces it entirely.


## clients/sailpoint.py — SailPointClient

Class that encapsulates all SailPoint API interaction.

Public methods:
- fetch_identities() -> List[dict] — paginate all identities, auto-refresh
  token on 401, retry with exponential backoff on transient errors
- fetch_attribute_definitions() -> List[str] — get attribute names from
  /beta/identity-attributes

Internal details:
- Token managed internally (callers never see it)
- Retry: 3 attempts, exponential backoff (1s, 2s, 4s) on 429/5xx
- Token refresh: automatic on 401 (both pagination and attribute fetch)
- Session lifecycle managed by the client


## clients/jira.py — JiraAssetsClient

Class that encapsulates the Jira Assets import workflow.

Public methods:
- update_mapping(mapping: dict) -> None
- sync(mapping, users, companies, managers) -> None — full import cycle

Private methods:
- _start_execution() — handles 409 conflicts (cancel + retry)
- _submit_data()
- _complete()
- _poll_status()

Mapping URL built from config (JIRA_WORKSPACE_ID, JIRA_IMPORT_SOURCE_ID)
instead of a hardcoded string.


## transforms/

Pure functions, no API calls.

filter.py:
- company_allowed(identity, allowed_set) -> bool
  Takes allowed set as parameter (testable, configurable).

reshape.py:
- reshape_identity(identity) -> dict — nested structure for Jira
- extract_companies_and_managers(identities) -> tuple[list, list] — deduplicate companies and managers

flatten.py:
- flatten_identity(identity, api_attributes) -> dict — flat structure for CSV
  Only used when --csv flag is passed.


## exporters/

mapping.py:
- build_mapping(attributes) -> dict — returns mapping dict in memory
- write_mapping(mapping, path) -> None — saves to disk for reference

This eliminates the current write-to-file-then-read-back pattern.
JiraAssetsClient receives the mapping dict directly.

json_export.py:
- write_json(users, companies, managers, path) -> None

csv_export.py:
- write_csv(rows, path) -> None


## main.py — Orchestrator

```python
def main(export_csv: bool = False) -> int:
    try:
        sp = SailPointClient()
        identities = sp.fetch_identities()
        filtered = [i for i in identities if company_allowed(i, ALLOWED_COMPANIES)]

        users = [reshape_identity(i) for i in filtered]
        companies, managers = extract_companies_and_managers(filtered)
        attributes = sp.fetch_attribute_definitions()
        mapping = build_mapping(attributes)

        write_json(users, companies, managers)
        write_mapping(mapping)

        if export_csv:
            write_csv(flatten_all(filtered, attributes))

        jira = JiraAssetsClient()
        jira.sync(mapping, users, companies, managers)

        log.info("sync completed successfully")
        return 0
    except Exception:
        log.exception("sync failed")
        return 1

if __name__ == "__main__":
    sys.exit(main("--csv" in sys.argv))
```

Exit codes: 0 = success, 1 = failure. Scheduler (cron, etc.) can detect failures.


## Logging

- Console handler + file handler (output/sync.log)
- Format: %(asctime)s [%(levelname)s] %(message)s
- Log rotation by size (5MB per file, 3 backups via RotatingFileHandler)
- Each run logs: start time, identities fetched, kept/skipped, Jira status, end time


## Scheduling

Not built into the code. Use OS-level scheduling:
```bash
/path/to/.venv/bin/python -m main
/path/to/.venv/bin/python -m main --csv
```

## Sync Strategy

Full sync every run. Jira Assets external import handles create/update
based on externalId matching. No state tracking needed.


## Decisions Made

- Full sync (not delta) — simpler, reliable, no state management
- CSV output is optional (--csv flag)
- No built-in scheduler — OS handles it
- build_mapping() returns dict, no file round-trip
- Settings centralized, credentials/ package removed
- Jira UUIDs in .env, not hardcoded
