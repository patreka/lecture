# Project Restructure Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Restructure the single-file SailPoint-to-Jira sync script into a modular package with config, clients, transforms, and exporters.

**Architecture:** Extract the 685-line `app/main.py` into focused modules. Each module has a single responsibility. The orchestrator (`main.py`) wires them together in ~30 lines. No behavior changes — same inputs, same outputs.

**Tech Stack:** Python 3.13, requests, python-dotenv

---

### Task 1: Create config/settings.py

**Files:**
- Create: `config/__init__.py`
- Create: `config/settings.py`
- Modify: `.env` (add JIRA_WORKSPACE_ID, JIRA_IMPORT_SOURCE_ID)

**Step 1: Add Jira UUIDs to .env**

Add to `.env`:
```
JIRA_WORKSPACE_ID=ea46e300-5869-4a5b-8a9f-16bfbf9e99a9
JIRA_IMPORT_SOURCE_ID=d2d66d42-cd72-4116-9283-50c4831deb02
```

**Step 2: Create config/settings.py**

```python
import os
import logging
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = PROJECT_ROOT / "output"

# SailPoint
SAILPOINT_CLIENT_ID = os.environ["SAILPOINT_CLIENT_ID"]
SAILPOINT_CLIENT_SECRET = os.environ["SAILPOINT_CLIENT_SECRET"]
SAILPOINT_BASE_URL = os.environ["SAILPOINT_BASE_URL"]
PAGE_SIZE = 250

# Jira Assets
JIRA_IMPORT_TOKEN = os.environ["JIRA_IMPORT_TOKEN"]
JIRA_WORKSPACE_ID = os.environ["JIRA_WORKSPACE_ID"]
JIRA_IMPORT_SOURCE_ID = os.environ["JIRA_IMPORT_SOURCE_ID"]

# Filtering
ALLOWED_COMPANIES = {
    "Ab Georgia LLC",
    "Adjarapay",
    "Advanced_Systems",
    "Cabarco",
}

# Retry
RETRYABLE_STATUSES = {429, 500, 502, 503, 504}
MAX_RETRIES = 3
```

**Step 3: Create empty config/__init__.py**

**Step 4: Create output/ directory**

Run: `mkdir -p output`

**Step 5: Verify**

Run: `.venv/bin/python -c "from config.settings import SAILPOINT_BASE_URL, JIRA_WORKSPACE_ID; print('OK:', SAILPOINT_BASE_URL)"`

Expected: `OK: https://cee-sb.api.identitynow.com`

---

### Task 2: Create clients/sailpoint.py

**Files:**
- Create: `clients/__init__.py`
- Create: `clients/sailpoint.py`

**Step 1: Create clients/sailpoint.py**

Extract from `app/main.py` lines 39-111 and 583-605 (`_raise`, `_request_with_retry`, `get_token`, `iter_identities`, `get_all_possible_attributes`).

```python
import logging
import time
from typing import Any, Dict, List

import requests

from config.settings import (
    SAILPOINT_BASE_URL,
    SAILPOINT_CLIENT_ID,
    SAILPOINT_CLIENT_SECRET,
    PAGE_SIZE,
    RETRYABLE_STATUSES,
    MAX_RETRIES,
)

log = logging.getLogger(__name__)


def _raise(r: requests.Response) -> None:
    if r.ok:
        return
    log.error("%s %s", r.status_code, r.text)
    r.raise_for_status()


class SailPointClient:
    def __init__(self):
        self._session = requests.Session()
        self._token = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._session.close()

    def _ensure_token(self) -> str:
        if not self._token:
            self._token = self._authenticate()
        return self._token

    def _authenticate(self) -> str:
        log.info("getting token")
        r = self._session.post(
            f"{SAILPOINT_BASE_URL}/oauth/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "client_id": SAILPOINT_CLIENT_ID,
                "client_secret": SAILPOINT_CLIENT_SECRET,
            },
            timeout=30,
        )
        _raise(r)
        return r.json()["access_token"]

    def _request_with_retry(self, method: str, url: str, **kwargs) -> requests.Response:
        for attempt in range(MAX_RETRIES):
            r = self._session.request(method, url, **kwargs)
            if r.status_code not in RETRYABLE_STATUSES:
                return r
            wait = 2 ** attempt
            log.warning(
                "retryable error %s, waiting %ss (attempt %s/%s)",
                r.status_code, wait, attempt + 1, MAX_RETRIES,
            )
            time.sleep(wait)
        return r

    def fetch_identities(self) -> List[Dict[str, Any]]:
        token = self._ensure_token()
        headers = {"Authorization": f"Bearer {token}"}
        url = f"{SAILPOINT_BASE_URL}/v2025/identities"
        offset = 0
        fetched = 0
        page_no = 0
        results = []

        while True:
            page_no += 1
            r = self._request_with_retry(
                "GET", url,
                headers=headers,
                params={"limit": PAGE_SIZE, "offset": offset},
                timeout=30,
            )

            if r.status_code == 401:
                log.warning("token expired, refreshing...")
                self._token = self._authenticate()
                token = self._token
                headers = {"Authorization": f"Bearer {token}"}
                r = self._request_with_retry(
                    "GET", url,
                    headers=headers,
                    params={"limit": PAGE_SIZE, "offset": offset},
                    timeout=30,
                )

            _raise(r)
            data = r.json()
            items = data if isinstance(data, list) else data.get("items", [])

            count = len(items)
            if count == 0:
                break

            fetched += count
            log.info("page %s: fetched data total = %s", page_no, fetched)
            results.extend(items)
            offset += PAGE_SIZE

        return results

    def fetch_attribute_definitions(self) -> List[str]:
        log.info("Fetching all possible identity attributes from API...")
        token = self._ensure_token()
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        url = f"{SAILPOINT_BASE_URL}/beta/identity-attributes"
        r = self._request_with_retry("GET", url, headers=headers, timeout=30)
        if not r.ok:
            log.warning("Could not fetch attribute definitions: %s", r.status_code)
            return []

        attrs = r.json()
        excluded_keywords = ["snapshotchanges", "triggersnapshots"]
        filtered = []
        for a in attrs:
            name = a.get("name")
            if not name:
                continue
            if any(kw in name.lower() for kw in excluded_keywords):
                continue
            filtered.append(name)

        return filtered
```

**Step 2: Create empty clients/__init__.py**

**Step 3: Verify**

Run: `.venv/bin/python -c "from clients.sailpoint import SailPointClient; print('OK')"`

Expected: `OK`

---

### Task 3: Create clients/jira.py

**Files:**
- Create: `clients/jira.py`

**Step 1: Create clients/jira.py**

Extract from `app/main.py` lines 455-580 (`jira_import`).

```python
import logging
import time
from typing import Any, Dict, List

import requests

from config.settings import JIRA_IMPORT_TOKEN, JIRA_WORKSPACE_ID, JIRA_IMPORT_SOURCE_ID

log = logging.getLogger(__name__)


def _raise(r: requests.Response) -> None:
    if r.ok:
        return
    log.error("%s %s", r.status_code, r.text)
    r.raise_for_status()


class JiraAssetsClient:
    def __init__(self):
        self._headers = {
            "Authorization": f"Bearer {JIRA_IMPORT_TOKEN}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _mapping_url(self) -> str:
        return (
            f"https://api.atlassian.com/jsm/assets/workspace/{JIRA_WORKSPACE_ID}"
            f"/v1/importsource/{JIRA_IMPORT_SOURCE_ID}/mapping"
        )

    def update_mapping(self, mapping: dict) -> None:
        log.info("updating jira assets mapping (PUT)...")
        r = requests.put(
            self._mapping_url(),
            headers=self._headers,
            json=mapping,
            timeout=30,
        )
        log.info("Mapping update status: %s", r.status_code)
        if r.ok:
            log.info("mapping updated successfully")
        else:
            log.error("Update failed: %s", r.text)
            log.info("Continuing with import...")

    def _discover_links(self) -> dict:
        r = requests.get(
            "https://api.atlassian.com/jsm/assets/v1/imports/info",
            headers=self._headers,
            timeout=30,
        )
        _raise(r)
        info = r.json()
        if isinstance(info, list):
            if not info:
                raise ValueError("Empty response from imports/info")
            return info[0].get("links", {})
        elif isinstance(info, dict):
            return info.get("links", {})
        else:
            raise ValueError(f"Unexpected response type from imports/info: {type(info)}")

    def _start_execution(self, links: dict) -> dict:
        start_url = links.get("start")
        if not start_url:
            raise ValueError("Missing 'start' link in imports/info")

        for attempt in range(5):
            r = requests.post(start_url, headers=self._headers, timeout=30)
            if r.status_code == 409:
                error_data = r.json()
                if error_data.get("errorCode") == "IN_PROGRESS":
                    log.warning("Import already in progress. Attempting to cancel/complete the ongoing execution...")
                    self._handle_conflict(links)
                    log.info("Waiting 10s before retry... (attempt %s/5)", attempt + 1)
                    time.sleep(10)
                    continue
            _raise(r)
            break
        else:
            _raise(r)

        return r.json()

    def _handle_conflict(self, links: dict) -> None:
        status_url = links.get("getStatus")
        if not status_url:
            return
        sr = requests.get(status_url, headers=self._headers, timeout=30)
        if not sr.ok:
            return
        status_data = sr.json()
        cancel_url = status_data.get("links", {}).get("cancel")
        if cancel_url:
            log.info("Cancelling execution at %s", cancel_url)
            cr = requests.post(cancel_url, headers=self._headers, timeout=30)
            log.info("Cancel status: %s", cr.status_code)
            results_url = f"{cancel_url}/results"
            requests.post(results_url, headers=self._headers, json={"completed": True}, timeout=30)
        else:
            log.warning("Cancel link not found, attempting to complete the execution via status link derivation")

    def _submit_and_complete(self, submit_url: str, users: list, companies: list, managers: list) -> None:
        payload = {
            "data": {
                "users": users,
                "companies": companies,
                "managers": managers,
            }
        }
        r = requests.post(submit_url, headers=self._headers, json=payload, timeout=30)
        _raise(r)

        r = requests.post(submit_url, headers=self._headers, json={"completed": True}, timeout=30)
        _raise(r)
        log.info("jira import completion signal sent")

    def _poll_status(self, links: dict) -> None:
        status_url = links.get("getStatus")
        if not status_url:
            return
        log.info("waiting for import to process...")
        last_status = None
        for _ in range(20):
            time.sleep(10)
            r = requests.get(status_url, headers=self._headers, timeout=30)
            if r.ok:
                status_data = r.json()
                current_status = status_data.get("status")
                log.info("Status: %s - Progress: %s%%", current_status, status_data.get("progress"))

                if last_status == "RUNNING" and current_status == "IDLE":
                    log.info("Import transitioned from RUNNING to IDLE, likely finished.")
                    break
                if current_status == "COMPLETED":
                    log.info("Import COMPLETED successfully.")
                    break
                if current_status == "FAILED":
                    log.error("Import failed: %s", status_data.get("statusMessage"))
                    break

                last_status = current_status
            else:
                log.error("Failed to get status: %s", r.status_code)

    def sync(self, mapping: dict, users: list, companies: list, managers: list) -> None:
        if not users:
            return
        log.info(
            "starting jira import for %s users, %s companies, %s managers",
            len(users), len(companies), len(managers),
        )

        self.update_mapping(mapping)

        links = self._discover_links()
        execution = self._start_execution(links)

        submit_url = execution.get("links", {}).get("submitResults")
        if not submit_url:
            raise ValueError("Missing 'submitResults' link after starting execution")

        self._submit_and_complete(submit_url, users, companies, managers)
        self._poll_status(links)
        log.info("jira import process finished")
```

**Step 2: Verify**

Run: `.venv/bin/python -c "from clients.jira import JiraAssetsClient; print('OK')"`

Expected: `OK`

---

### Task 4: Create transforms/

**Files:**
- Create: `transforms/__init__.py`
- Create: `transforms/filter.py`
- Create: `transforms/reshape.py`
- Create: `transforms/flatten.py`

**Step 1: Create transforms/filter.py**

Extract from `app/main.py` lines 206-209.

```python
from typing import Any, Dict, Set


def company_allowed(identity: Dict[str, Any], allowed: Set[str]) -> bool:
    attrs = identity.get("attributes") or {}
    company = attrs.get("companyName")
    return company in allowed
```

**Step 2: Create transforms/reshape.py**

Extract from `app/main.py` lines 156-203 and manager/company extraction from lines 643-660.

```python
from typing import Any, Dict, List, Tuple


def reshape_identity(ident: Dict[str, Any]) -> Dict[str, Any]:
    email_address = ident.get("emailAddress")
    reshaped = {
        "id": ident.get("id"),
        "name": ident.get("name"),
        "emailAddress": email_address,
        "alias": ident.get("alias"),
    }

    mgr = ident.get("managerRef", {}) or {}
    reshaped["managerRef"] = {
        "type": mgr.get("type"),
        "id": mgr.get("id"),
        "name": mgr.get("name"),
    }

    ls = ident.get("lifecycleState", {}) or {}
    reshaped["lifecycleState"] = {
        "stateName": ls.get("stateName"),
        "manuallyUpdated": ls.get("manuallyUpdated"),
    }

    attrs = ident.get("attributes", {}) or {}
    hr_attributes = {}
    for k, v in attrs.items():
        if k.lower() in ("snapshotchanges", "triggersnapshots"):
            continue
        if k.lower() == "email" and v == email_address:
            continue
        hr_attributes[k] = v
    reshaped["attributes"] = hr_attributes

    return reshaped


def extract_companies_and_managers(
    identities: List[Dict[str, Any]],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    companies_seen: set = set()
    companies: List[Dict[str, Any]] = []
    managers_seen: set = set()
    managers: List[Dict[str, Any]] = []

    for ident in identities:
        company_name = ident.get("attributes", {}).get("companyName")
        if company_name and company_name not in companies_seen:
            companies_seen.add(company_name)
            companies.append({"name": company_name, "companyId": None})

        mgr = ident.get("managerRef") or {}
        mgr_id = mgr.get("id")
        if mgr_id and mgr_id not in managers_seen:
            managers_seen.add(mgr_id)
            managers.append({"id": mgr_id, "name": mgr.get("name")})

    return companies, managers
```

**Step 3: Create transforms/flatten.py**

Extract from `app/main.py` lines 114-153.

```python
from typing import Any, Dict, List


def flatten_identity(ident: Dict[str, Any]) -> Dict[str, Any]:
    flat = {
        k: v for k, v in ident.items()
        if k != "attributes" and not isinstance(v, (dict, list))
    }

    attrs = ident.get("attributes", {}) or {}
    email_address = ident.get("emailAddress")

    for k, v in attrs.items():
        if k.lower() in ("snapshotchanges", "triggersnapshots"):
            continue
        if k.lower() == "email" and v == email_address:
            continue
        if k not in flat:
            flat[k] = v
        else:
            flat[f"attr_{k}"] = v

    mgr = ident.get("managerRef", {}) or {}
    for k, v in mgr.items():
        key = f"manager_{k}" if k != "name" else "manager"
        if key not in flat:
            flat[key] = v
        else:
            flat[f"mgr_{k}"] = v

    ls = ident.get("lifecycleState", {}) or {}
    for k, v in ls.items():
        if k not in flat:
            flat[k] = v
        else:
            flat[f"lifecycle_{k}"] = v

    return flat


def flatten_all(identities: List[Dict[str, Any]], api_attributes: List[str]) -> List[Dict[str, Any]]:
    rows = []
    for ident in identities:
        flat = flatten_identity(ident)
        for attr in api_attributes:
            if attr not in flat:
                flat[attr] = None
        rows.append(flat)
    return rows
```

**Step 4: Create empty transforms/__init__.py**

**Step 5: Verify**

Run: `.venv/bin/python -c "from transforms.filter import company_allowed; from transforms.reshape import reshape_identity; from transforms.flatten import flatten_identity; print('OK')"`

Expected: `OK`

---

### Task 5: Create exporters/

**Files:**
- Create: `exporters/__init__.py`
- Create: `exporters/mapping.py`
- Create: `exporters/json_export.py`
- Create: `exporters/csv_export.py`

**Step 1: Create exporters/mapping.py**

Extract from `app/main.py` lines 245-452. Split into `build_mapping()` and `write_mapping()`.

```python
import json
import logging
from pathlib import Path
from typing import Any, Dict, List

log = logging.getLogger(__name__)


def build_mapping(api_attributes: List[str]) -> Dict[str, Any]:
    user_schema_attributes = [
        {
            "externalId": "object-type-attribute/user-id",
            "name": "Id",
            "type": "text",
            "minimumCardinality": 1,
            "maximumCardinality": 1,
        },
        {
            "externalId": "object-type-attribute/user-displayname",
            "name": "Display Name",
            "type": "text",
            "label": True,
            "minimumCardinality": 1,
            "maximumCardinality": 1,
        },
        {
            "externalId": "object-type-attribute/user-email",
            "name": "Email Address",
            "type": "text",
            "minimumCardinality": 0,
            "maximumCardinality": 1,
        },
        {
            "externalId": "object-type-attribute/user-company",
            "name": "Company",
            "type": "referenced_object",
            "referenceObjectTypeExternalId": "object-type/company",
            "minimumCardinality": 0,
            "maximumCardinality": 1,
        },
        {
            "externalId": "object-type-attribute/user-manager",
            "name": "Manager",
            "type": "referenced_object",
            "referenceObjectTypeExternalId": "object-type/manager",
            "minimumCardinality": 0,
            "maximumCardinality": 1,
        },
    ]

    user_attr_mappings = [
        {
            "attributeExternalId": "object-type-attribute/user-id",
            "attributeName": "Id",
            "attributeLocators": ["id"],
            "externalIdPart": True,
        },
        {
            "attributeExternalId": "object-type-attribute/user-displayname",
            "attributeName": "Display Name",
            "attributeLocators": ["attributes.displayName"],
        },
        {
            "attributeExternalId": "object-type-attribute/user-email",
            "attributeName": "Email Address",
            "attributeLocators": ["emailAddress"],
        },
        {
            "attributeExternalId": "object-type-attribute/user-company",
            "attributeName": "Company",
            "attributeLocators": ["attributes.companyName"],
            "objectMappingIQL": "Name = ${attributes.companyName}",
        },
        {
            "attributeExternalId": "object-type-attribute/user-manager",
            "attributeName": "Manager",
            "attributeLocators": ["managerRef.name"],
            "objectMappingIQL": "Name = ${managerRef.name}",
        },
    ]

    for attr in api_attributes:
        if attr.lower() in ["displayname", "companyname", "manager"]:
            continue

        display_name = attr.replace(".", " ").title()
        ext_id = f"object-type-attribute/user-{attr.lower().replace('.', '-')}"

        if attr.lower() == "email":
            ext_id = "object-type-attribute/user-email-attr"
            display_name = "Email Attribute"

        user_schema_attributes.append({
            "externalId": ext_id,
            "name": display_name,
            "type": "text",
            "minimumCardinality": 0,
            "maximumCardinality": 1,
        })

        user_attr_mappings.append({
            "attributeExternalId": ext_id,
            "attributeName": display_name,
            "attributeLocators": [f"attributes.{attr}"],
        })

    return {
        "schema": {
            "objectSchema": {
                "name": "User - UAT External Import",
                "description": "Imported from SailPoint JSON",
                "objectTypes": [
                    {
                        "externalId": "object-type/company",
                        "name": "Company",
                        "attributes": [
                            {
                                "externalId": "object-type-attribute/company-name",
                                "name": "Name",
                                "type": "text",
                                "label": True,
                                "minimumCardinality": 1,
                                "maximumCardinality": 1,
                            }
                        ],
                    },
                    {
                        "externalId": "object-type/manager",
                        "name": "Manager",
                        "attributes": [
                            {
                                "externalId": "object-type-attribute/manager-id",
                                "name": "Id",
                                "type": "text",
                                "minimumCardinality": 1,
                                "maximumCardinality": 1,
                            },
                            {
                                "externalId": "object-type-attribute/manager-name",
                                "name": "Name",
                                "type": "text",
                                "label": True,
                                "minimumCardinality": 1,
                                "maximumCardinality": 1,
                            },
                        ],
                    },
                    {
                        "externalId": "object-type/user",
                        "name": "User",
                        "attributes": user_schema_attributes,
                    },
                ],
            }
        },
        "mapping": {
            "objectTypeMappings": [
                {
                    "objectTypeExternalId": "object-type/company",
                    "objectTypeName": "Company",
                    "selector": "companies",
                    "attributesMapping": [
                        {
                            "attributeExternalId": "object-type-attribute/company-name",
                            "attributeName": "Name",
                            "attributeLocators": ["name"],
                            "externalIdPart": True,
                        }
                    ],
                },
                {
                    "objectTypeExternalId": "object-type/manager",
                    "objectTypeName": "Manager",
                    "selector": "managers",
                    "attributesMapping": [
                        {
                            "attributeExternalId": "object-type-attribute/manager-id",
                            "attributeName": "Id",
                            "attributeLocators": ["id"],
                            "externalIdPart": True,
                        },
                        {
                            "attributeExternalId": "object-type-attribute/manager-name",
                            "attributeName": "Name",
                            "attributeLocators": ["name"],
                            "externalIdPart": True,
                        },
                    ],
                },
                {
                    "objectTypeExternalId": "object-type/user",
                    "objectTypeName": "User",
                    "selector": "users",
                    "attributesMapping": user_attr_mappings,
                },
            ]
        },
    }


def write_mapping(mapping: dict, path: Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(mapping, f, indent=4, ensure_ascii=False)
    log.info("mapping written: %s", path)
```

**Step 2: Create exporters/json_export.py**

```python
import json
import logging
from pathlib import Path
from typing import Any, Dict, List

log = logging.getLogger(__name__)


def write_json(
    users: List[Dict[str, Any]],
    companies: List[Dict[str, Any]],
    managers: List[Dict[str, Any]],
    path: Path,
) -> None:
    data = {
        "users": users,
        "companies": companies,
        "managers": managers,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    log.info(
        "json written: %s (%s users, %s companies, %s managers)",
        path, len(users), len(companies), len(managers),
    )
```

**Step 3: Create exporters/csv_export.py**

```python
import csv
import logging
from pathlib import Path
from typing import Any, Dict, List

log = logging.getLogger(__name__)


def write_csv(rows: List[Dict[str, Any]], path: Path) -> None:
    if not rows:
        log.warning("no data")
        return

    all_fields = set()
    for row in rows:
        all_fields.update(row.keys())
    fields = sorted(list(all_fields))

    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

    log.info("csv written: %s (%s rows)", path, len(rows))
```

**Step 4: Create empty exporters/__init__.py**

**Step 5: Verify**

Run: `.venv/bin/python -c "from exporters.mapping import build_mapping; from exporters.json_export import write_json; from exporters.csv_export import write_csv; print('OK')"`

Expected: `OK`

---

### Task 6: Create new main.py orchestrator

**Files:**
- Create: `main.py` (project root)

**Step 1: Create main.py**

```python
import logging
import sys

from config.settings import ALLOWED_COMPANIES, OUTPUT_DIR
from clients.sailpoint import SailPointClient
from clients.jira import JiraAssetsClient
from transforms.filter import company_allowed
from transforms.reshape import reshape_identity, extract_companies_and_managers
from transforms.flatten import flatten_all
from exporters.mapping import build_mapping, write_mapping
from exporters.json_export import write_json
from exporters.csv_export import write_csv

log = logging.getLogger(__name__)


def main(export_csv: bool = False) -> int:
    try:
        OUTPUT_DIR.mkdir(exist_ok=True)

        with SailPointClient() as sp:
            all_identities = sp.fetch_identities()
            api_attributes = sp.fetch_attribute_definitions()

        log.info("Discovered %s attributes from API definition.", len(api_attributes))

        # Filter
        filtered = [i for i in all_identities if company_allowed(i, ALLOWED_COMPANIES)]
        log.info(
            "total identities: %s, kept: %s, skipped: %s",
            len(all_identities), len(filtered), len(all_identities) - len(filtered),
        )

        # Transform
        users = [reshape_identity(i) for i in filtered]
        companies, managers = extract_companies_and_managers(filtered)

        # Export
        mapping = build_mapping(api_attributes)
        write_mapping(mapping, OUTPUT_DIR / "mapping.json")
        write_json(users, companies, managers, OUTPUT_DIR / "sailpoint_with_filter.json")

        if export_csv:
            rows = flatten_all(filtered, api_attributes)
            write_csv(rows, OUTPUT_DIR / "sailpoint_with_filter.csv")

        # Sync to Jira
        jira = JiraAssetsClient()
        jira.sync(mapping, users, companies, managers)

        log.info("sync completed successfully")
        return 0
    except Exception:
        log.exception("sync failed")
        return 1


if __name__ == "__main__":
    sys.exit(main("--csv" in sys.argv))
```

**Step 2: Verify import chain**

Run: `.venv/bin/python -c "import main; print('OK')"`

Expected: `OK`

---

### Task 7: Clean up old files

**Files:**
- Delete: `app/main.py`
- Delete: `app/__init__.py`
- Delete: `credentials/sailpoint_creds.py`
- Delete: `credentials/jira_creds.py`
- Delete: `credentials/__init__.py`

**Step 1: Remove old files**

```bash
rm app/main.py app/__init__.py
rm -r credentials/
rm -r app/
```

**Step 2: Verify full run**

Run: `.venv/bin/python main.py`

Expected: Script authenticates, fetches identities, filters, exports JSON + mapping, sends to Jira. Same behavior as before.

**Step 3: Verify with --csv flag**

Run: `.venv/bin/python main.py --csv`

Expected: Same as above + CSV file generated in output/.

---

### Task 8: Update CHANGELOG.txt

**Files:**
- Modify: `CHANGELOG.txt`

Move items 10-14 from PLANNED to COMPLETED with actual details of what was done.

---

## Final Project Structure

```
sailpoint/
├── config/
│   ├── __init__.py
│   └── settings.py
├── clients/
│   ├── __init__.py
│   ├── sailpoint.py
│   └── jira.py
├── transforms/
│   ├── __init__.py
│   ├── filter.py
│   ├── flatten.py
│   └── reshape.py
├── exporters/
│   ├── __init__.py
│   ├── csv_export.py
│   ├── json_export.py
│   └── mapping.py
├── output/                   (generated)
├── docs/plans/
├── main.py
├── .env
├── .gitignore
├── requirements.txt
└── CHANGELOG.txt
```
