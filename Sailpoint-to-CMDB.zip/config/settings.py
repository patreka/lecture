import os
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

_log_format = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

_console = logging.StreamHandler()
_console.setFormatter(_log_format)

_file = RotatingFileHandler(
    OUTPUT_DIR / "sync.log", maxBytes=5_000_000, backupCount=3,
)
_file.setFormatter(_log_format)

logging.basicConfig(level=logging.INFO, handlers=[_console, _file])

# SailPoint
SAILPOINT_CLIENT_ID = os.environ["SAILPOINT_CLIENT_ID"]
SAILPOINT_CLIENT_SECRET = os.environ["SAILPOINT_CLIENT_SECRET"]
SAILPOINT_BASE_URL = os.environ["SAILPOINT_BASE_URL"]
PAGE_SIZE = 250

# Jira Assets
JIRA_WORKSPACE_ID = os.environ["JIRA_WORKSPACE_ID"]

# Filtering
ALLOWED_COMPANIES = {
    "Ab Georgia LLC",
    "Adjarapay",
    "Advanced_Systems",
    "Cabarco",
    "Singular Group Georgia LLC",
    "Singular Trading Limited",
    "Singular Group Skopje LLC",
}

# SailPoint company name -> CMDB company name mapping
# SailPoint names may differ from what's in Jira CMDB
COMPANY_NAME_MAP = {
    "Ab Georgia LLC": "Ab Georgia LLC",
    "Adjarapay": "Adjarapay LLC",
    "Advanced_Systems": "Advanced Systems LLC",
    "Cabarco": "Cabarco LLC",
    "Singular Group Georgia LLC": "Singular Group Georgia LLC",
    "Singular Trading Limited": "Singular Trading Limited",
    "Singular Group Skopje LLC": "Singular Group Skopje LLC",
}

# Retry
RETRYABLE_STATUSES = {429, 500, 502, 503, 504}
MAX_RETRIES = 3

# User attribute mapping: (jira_name, source_path, type)
# source_path uses dot notation: "attributes.fieldName" or top-level "id", "name", etc.
# type: "text" or "referenced_object"
USER_ATTRIBUTES = [
    ("Employee ID", "name", "text"),
    ("Legal Name", "displayName", "text"),
    ("Email - Work", "email", "text"),
    ("Business Title", "attributes.title", "text"),
    ("Supervisory Organization", "attributes.supervisoryOrganization", "text"),
    ("Manager", "manager.name", "referenced_object"),  # -> User_1 (by Employee ID)
    ("Manager Employee ID", "manager.name", "text"),
    ("Company", "attributes.companyName", "referenced_object"),  # -> Company_1
    ("Cost Center", "attributes.costCenter", "text"),
    ("Active Status", "attributes.identityState", "text"),
    ("Termination Date", "attributes.endDate", "text"),
    ("Manager +2 Employee ID", "attributes.superiorOrganizationManagerId1", "text"),
    ("Manager +3 Employee ID", "attributes.superiorOrganizationManagerId2", "text"),
    ("Manager +4 Employee ID", "attributes.superiorOrganizationManagerId3", "text"),
    ("Manager +5 Employee ID", "attributes.superiorOrganizationManagerId4", "text"),
    ("Manager +6 Employee ID", "attributes.superiorOrganizationManagerId5", "text"),
    ("Jira", "attributes.jiraAttributeId", "text"),
]
