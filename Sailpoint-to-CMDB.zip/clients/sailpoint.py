import logging
import time
from typing import Any, Dict, List

import requests
import truststore

from config.settings import (
    SAILPOINT_BASE_URL,
    SAILPOINT_CLIENT_ID,
    SAILPOINT_CLIENT_SECRET,
    PAGE_SIZE,
    RETRYABLE_STATUSES,
    MAX_RETRIES,
)
from clients.utils import raise_for_error

# Use the OS certificate store (Windows/macOS/Linux) for SSL verification.
truststore.inject_into_ssl()

log = logging.getLogger(__name__)

MAX_PAGES = 1000


class SailPointClient:
    def __init__(self):
        self._session = requests.Session()
        self._token = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._session.close()

    def _ensure_token(self) -> str:
        if not self._token:
            self._token = self._authenticate()
        return self._token

    def _authenticate(self) -> str:
        log.info("getting token")
        r = self._session.post(
            f"{SAILPOINT_BASE_URL}/oauth/token",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "client_id": SAILPOINT_CLIENT_ID,
                "client_secret": SAILPOINT_CLIENT_SECRET,
            },
            timeout=30,
        )
        raise_for_error(r)
        return r.json()["access_token"]

    def _request_with_retry(self, method: str, url: str, **kwargs) -> requests.Response:
        if MAX_RETRIES < 1:
            raise ValueError("MAX_RETRIES must be >= 1")

        for attempt in range(MAX_RETRIES):
            r = self._session.request(method, url, **kwargs)

            # Handle token expiry inline
            if r.status_code == 401:
                log.warning("token expired, refreshing...")
                self._token = self._authenticate()
                kwargs.setdefault("headers", {})["Authorization"] = f"Bearer {self._token}"
                r = self._session.request(method, url, **kwargs)
                if r.status_code == 401:
                    raise_for_error(r)

            if r.status_code not in RETRYABLE_STATUSES:
                return r

            retry_after = r.headers.get("Retry-After")
            if retry_after:
                try:
                    wait = int(retry_after)
                except ValueError:
                    wait = 2 ** attempt
            else:
                wait = 2 ** attempt

            log.warning(
                "retryable error %s, waiting %ss (attempt %s/%s)",
                r.status_code, wait, attempt + 1, MAX_RETRIES,
            )
            time.sleep(wait)
        return r

    def fetch_identities(self) -> List[Dict[str, Any]]:
        """Fetch all identities using the Search API with searchAfter pagination."""
        self._ensure_token()
        url = f"{SAILPOINT_BASE_URL}/v2025/search"
        search_after = []
        results = []

        for page_no in range(1, MAX_PAGES + 1):
            body = {
                "indices": ["identities"],
                "query": {"query": "*"},
                "sort": ["id"],
            }
            if search_after:
                body["searchAfter"] = search_after

            r = self._request_with_retry(
                "POST", url,
                headers={"Authorization": f"Bearer {self._token}"},
                json=body,
                params={"limit": PAGE_SIZE},
                timeout=30,
            )

            raise_for_error(r)
            items = r.json()

            if not items:
                break

            results.extend(items)
            log.info("page %s: fetched data total = %s", page_no, len(results))

            last_id = items[-1].get("id")
            if not last_id:
                log.error("last identity on page %s has no 'id' field, stopping pagination", page_no)
                break
            search_after = [last_id]
        else:
            log.warning("reached maximum page limit (%s), stopping pagination", MAX_PAGES)

        return results
