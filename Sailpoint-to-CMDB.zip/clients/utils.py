import logging

import requests

log = logging.getLogger(__name__)


def raise_for_error(r: requests.Response) -> None:
    if r.ok:
        return
    log.error("%s %s", r.status_code, r.text)
    r.raise_for_status()
