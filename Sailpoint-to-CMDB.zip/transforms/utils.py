from typing import Any, Dict


def get_value(obj: Dict[str, Any], path: str) -> Any:
    """Extract value from nested dict using dot notation path.

    Returns empty string for missing/None values so that downstream consumers
    (Jira import, CSV export) receive a consistent string type. This means
    absent fields like identityState will be treated as inactive by transform_value.
    """
    parts = path.split(".")
    current = obj
    for part in parts:
        if current is None or not isinstance(current, dict):
            return None
        current = current.get(part)
    return current if current is not None else ""


def transform_value(jira_name: str, value: Any) -> Any:
    """Apply business-rule transformations based on attribute name."""
    if jira_name == "Active Status":
        return "Yes" if str(value).upper() == "ACTIVE" else "No"
    return value
