import logging
from typing import Any, Dict, Set

log = logging.getLogger(__name__)


def company_allowed(identity: Dict[str, Any], allowed: Set[str]) -> bool:
    attrs = identity.get("attributes") or {}
    company = attrs.get("companyName")
    if not company:
        log.debug("skipping identity %s: companyName is missing or null", identity.get("name", "unknown"))
        return False
    if company not in allowed:
        log.debug("skipping identity %s: company '%s' not in allowed set", identity.get("name", "unknown"), company)
        return False
    return True
